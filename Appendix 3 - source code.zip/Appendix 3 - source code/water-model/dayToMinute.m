function res = dayToMinute(value) 
    res = value/24/60;
end