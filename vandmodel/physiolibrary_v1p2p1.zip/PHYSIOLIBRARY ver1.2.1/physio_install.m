function f=physio_install
global pthSrcLib pthSrcHlp pthSrcLibMyVer pthSrcHlpMyVer pthDstLib pthDstHlp w maxwait
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%      PhysioLibrary Instalator ver 1.2.1            %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
f=0;

%ujisteni, zda chci vubec neco instalovat
buttonName=questdlg('Welcome to the "PHYSIOLOGY BLOCKSET" for MATLAB/SIMULINK installing procedure! This component is being developed in the Laboratory of Biocybernetics and Computer Aided Teaching is part of the Institute of Pathophysiology of the 1st Faculty of Medicine, Charles University in Prague (http://patf-biokyb.lf1.cuni.cz). During the installation procedure new files will be copied into the MATLAB directory and registered in MATLAB path and help system. If you don''t agree with these changes, please abort the istallation procedure.','PHYSIO Installation','Install','Abort','Abort');
switch buttonName
    case 'Install',
        disp('Installation of "Physiology BlockSet" has been started.');
    case 'Abort',
        disp('Installation has been interrupted. No changes to MATLAB environment have been done.');
        return;
end;

%%% zjisti, v ktere verzi matlabu vlastne je: R13/R13SP1   vs.  R14
structVer = ver('simulink');
strMyVer = structVer.Release;  % hodnoty: '(R13)' / '(R13SP1)' / '(R14)' / '(R14SP1)' / '(R14SP2)' / '(R14SP3)' / '(R2006a+)' / '(R2006b)' / '(R2007b)'

%%% definice waitbaru
hw = waitbar(0,'Please, be patient...');%WAITBAR%WAITBAR%WAITBAR
maxwait=10;w=0;
w=mod(w+1,maxwait);waitbar(w/maxwait,hw,'I make up directory names'); %%%%%%%%%%%%%%%%

%%% skladam cesty (platformy maji ruzne oddelovace) 
pthDstLib = fullfile(matlabroot,'toolbox','physio'); % cilove cesty
pthDstHlp = fullfile(matlabroot,'help','toolbox','physio');
pthXmlTmp = fullfile(matlabroot,'toolbox','physio','tmp'); % Tmp adresar pro upravy
w=mod(w+1,maxwait);waitbar(w/maxwait,hw);%WAITBAR%WAITBAR%WAITBAR%%WAITBAR

pthSrcLib = fullfile(pwd,'all_ver','library');      % cesta ke zdroji pro instalac
pthSrcHlp = fullfile(pwd,'all_ver','help');         % pwd=current working directory, MATLAB\work by default
switch strMyVer % zdroje dat pro ruzne verze MATLABu
    case {'(R13)','(R13SP1)'}
        pthMwDocTocXml = fullfile(matlabroot,'help','mwdoctoc.xml'); % XML pro centralni registraci helpu
        pthSrcLibMyVer = fullfile(pwd,'r13','library');      % cesta ke zdroji pro instalac
        pthSrcHlpMyVer = fullfile(pwd,'r13','help');         % pwd=current working directory, MATLAB\work by default
    case {'(R14)','(R14SP1)','(R14SP2)','(R14SP3)'}
        pthSrcLibMyVer = fullfile(pwd,'r14','library');      % cesta ke zdroji pro instalac
        pthSrcHlpMyVer = fullfile(pwd,'r14','help');         % pwd=current working directory, MATLAB\work by default
    case {'(R2006a+)','(R2006b)','(R2007a)','(R2007b)','(R2008a)'};
        pthSrcLibMyVer = fullfile(pwd,'r2006','library');      % cesta ke zdroji pro instalac
        pthSrcHlpMyVer = fullfile(pwd,'r2006','help');         % pwd=current working directory, MATLAB\work by default

    otherwise
        close(hw);
        h=msgbox('The Instalator can''t recognize the version of MATLAB. The instalation is abborted at row 49!!!'...
            ,'Instalation of PhysiologyBlockset Abborted','error');
        uiwait(h);
        return;
end %end switch
w=mod(w+1,maxwait);waitbar(w/maxwait,hw,'Copying files...');%WAITBAR%WAITBAR%WAITBAR%%WAITBAR

%%% Pokud cilove adresare jiz existuji, vycistime je.
if or(exist(pthDstLib)==7,exist(pthDstHlp)==7)
    buttonName=questdlg('"PHYSIOLOGY BLOCKSET" directories already exist! Do you want overwrite their content?', 'PHYSIO Installation','YES - Overwrite','NO - Abort installation','YES - Overwrite');
    succes1=1;
    succes2=1;
    errsvpth=0;
    switch buttonName,  %POZOR! polozky musi souhlasit s vystupy predchazejiciho dialogu!!!
        case 'YES - Overwrite',
            warning off MATLAB:rmpath:DirNotFound;
            rmpath(pthDstLib);% odebere cestu ze "search path"
            switch strMyVer % Zachova "search path" i pro pristi spusteni MATLABu. (Zavisi na verzi MATLABu)
                case {'(R13)','(R13SP1)'}
                    error1=path2rc;
                case {'(R14)','(R14SP1)','(R14SP2)','(R14SP3)','(R2006a+)','(R2006b)','(R2007a)','(R2007b)','(R2008a)'}
                    error1=savepath;
            end;
            warning on MATLAB:rmpath:DirNotFound;
            if (exist(pthDstLib)==7)
                [succes1,mess1]=rmdir(pthDstLib,'s');
            end;
            if exist(pthDstHlp)==7
                [succes2,mess2]=rmdir(pthDstHlp,'s');
            end;
        case 'NO - Abort installation',
            close(hw);
            h=msgbox('Aborting installation on user''s request. "PHYSIOLOGY BLOCKSET" directories already existed before starting this installer. Make sure if "PHYSIOLOGY BLOCKSET" is not already installed, otherwise restart the installer and choose Overwrite.'...
                ,'Instalator of PhysiologyBlockset','warn');
            uiwait(h);
            return;
        otherwise
            disp('Nauc se programovat, osle.');
            close(hw);
            return;
    end
    if (succes1==0)||(succes2==0)||(error1==1)
        h=errordlg(['Installation failed!!!  To fix this problem, please delete directories: ',pthDstLib,' and ',pthDstHlp,' and remove from "MATLAB search path" : ',pthDstLib],'Aborting installation! Problem with directories occured.');
        uiwait(h);
        close(hw);
        return;
    else
        w=mod(w+1,maxwait);waitbar(w/maxwait,hw,'Copyig of files in progress...');%WAITBAR%WAITBAR%WAITBAR%%WAITBAR
    end;
end;

%%% kopirovani souboru:  1,3 ... soubory kopirovane vzdy
%%%                      2,4 ... speciality dle verzi
[succes1,mess1,messid1]=copyfile(pthSrcLib,pthDstLib);
[succes2,mess2,messid2]=copyfile(pthSrcLibMyVer,pthDstLib);
w=mod(w+1,maxwait);waitbar(w/maxwait,hw);%WAITBAR%WAITBAR%WAITBAR%%WAITBAR
[succes3,mess3,messid3]=copyfile(pthSrcHlp,pthDstHlp);
[succes4,mess4,messid4]=copyfile(pthSrcHlpMyVer,pthDstHlp);
w=mod(w+1,maxwait);waitbar(w/maxwait,hw,'Updating "MATLAB search path"');%WAITBAR%WAITBAR%WAITBAR%%WAITBAR
if ~((succes1==1)&&(succes2==1)) %chyba pri kopirovani
    h=errordlg('Aborting installation! File copy failed. Possible cause - source files not found in the current directory.','Aborting installation! File copy failed.');
    uiwait(h);
    close(hw);
    return;
end;

%%% aktualizace Matlab Search Paths
addpath(pthDstLib,'-end')  %prida cestu ke knihovne do "search path" (jen aktualni spusteni MATLABu)
switch strMyVer % Zachova "search path" i pro pristi spusteni MATLABu. (Zavisi na verzi MATLABu)
    case {'(R13)','(R13SP1)'}
        error1=path2rc;
    case {'(R14)','(R14SP1)','(R14SP2)','(R14SP3)','(R2006a+)','(R2006b)','(R2007a)','(R2007b)','(R2008a)'}
        error1=savepath;
end;

w=mod(w+1,maxwait);waitbar(w/maxwait,hw,'Backing up "MWDocToc.XML"');%WAITBAR%WAITBAR%WAITBAR%%WAITBAR
if ~(error1==0)  %%%%%%%%%%%%
    buttonName=questdlg('Failed to store updated "MATLAB search path"! ', 'PHYSIO Installation','Ignore','Abort','Ignore');
    switch buttonName
        case 'Ignore';
            h=msgbox('Resuming installation. Try to update and save the path manually after finishing the installation. ("..\Toolbox\Physio\PhysioLib.mdl")','Instalator of PhysiologyBlockset','warn');
            uiwait(h);
        case 'Abort';
            h=msgbox(['Aborting installation on user''s request. Some files have been already copied to: ',pthDstLib,' a ',pthDstHlp,' .'],'Instalator of PhysiologyBlockset','error');
            uiwait(h);
            close(hw);
            return;
    end;
end;

%%% Registrace souboru pro help a registrace knihovny.
%%% Tato sekce je silne odlisna pro ruzne verze Matlabu !!!!
switch strMyVer
    case {'(R13)','(R13SP1)'} % v teto verzi Matlabu je nutna uprava souboru MwDocToc.Xml
        if exist(pthMwDocTocXml)==2;
            [succes,xmlbakdir,xmlbakfile]=zalohujxml(pthMwDocTocXml);
            w=mod(w+1,maxwait);waitbar(w/maxwait,hw,'Checking "MWDocToc.XML"');%WAITBAR%WAITBAR%WAITBAR%%WAITBAR
            if succes %%%%%%%% uprava MWDOCTOC.XML
                if  (najdi(xmlbakfile,'Physiology Blockset')==-1)
                    upravxml(xmlbakdir,xmlbakfile);%UPRAVUJE *.XML
                    w=mod(w+1,maxwait);waitbar(w/maxwait,hw,'Updating "MWDocToc.XML"');%WAITBAR%WAITBAR%WAITBAR%%WAITBAR
                    [succes,mess,messid]=copyfile(fullfile(xmlbakdir,'edit.xml'),pthMwDocTocXml); %starou verzi xml nahrad novou
                    w=mod(w+1,maxwait);waitbar(w/maxwait,hw,'Saving updated "MWDocToc.XML"');%WAITBAR%WAITBAR%WAITBAR%%WAITBAR
                    if ~succes
                        h=msgbox(['Installation failed!!!  To fix this problem, please restore ',pthMwDocTocXml,' from backup ',xmlbakfile,' .'],'Instalator of PhysiologyBlockset','error');
                        uiwait(h);
                        close(hw);
                        return;
                    end;
                else
                    h=msgbox('Help system table of contents "MWDocToc.XML" is already up-to-date. Leaving unchanged','Instalator of PhysiologyBlockset','warn');
                    uiwait(h);
                end;
            else
                h=msgbox(['Installation failed!!! Failed to back up "MWDocToc.XML". Check the access rights for ',fullfile(matlabroot,'work'),' .'],'Instalator of PhysiologyBlockset','error');
                uiwait(h);
                close(hw);
                return
            end;
        else
            h=msgbox(['Installation failed!!! "MWDocToc.XML" not found on the path: ',fullfile(matlabroot,'help'),' .'],'Instalator of PhysiologyBlockset','error');
            uiwait(h);
            close(hw);
            return;
        end;
    case {'(R14)','(R14SP1)','(R14SP2)','(R14SP3)','(R2006a+)','(R2006b)','(R2007a)','(R2007b)','(R2008a)'}
        %v teto verzi Matlabu se zadne soubory explicitne neupravuji
    otherwise
        close(hw);
        h=msgbox('The Instalator can''t recognize the version of MATLAB. The files may be unregistered!!! Edit MwDocToc.xml manualy if you have the R13 version.'...
            ,'Instalation of PhysiologyBlockset Abborted','error');
        uiwait(h);
        return;
end %end switch

%%%uzaviraci formule
close(hw);
buttonName=questdlg('Congratulations! "PHYSIOLOGY BLOCKSET" has been installed successfully. It might be neccessary to restart MATLAB for the changes to take effect. Do you want to shut MATLAB down now or continue your session and restart MATLAB later?','Instalator of PhysiologyBlockset','Shut down MATLAB','Later','Shut down MATLAB');
switch buttonName
    case 'Shut down MATLAB'
        disp('Terminating sucessfully the instalation of Physiology BlockSet & Exiting MATLAB');
        quit;
    case 'Later'
        disp('Terminating sucessfully the instalation of Physiology BlockSet');
        disp('Changes may take efect after restarting MATLAB.');
%        return;
end;
%return;
pause(1);

function f=upravxml(xmlbakdir,xmlbakfile)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%  upravi MwDocToc.Xml pro verzi Matlab R13/R13SP1 %%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
f=0;
str=' ';
pos=0;
pos=najdi(xmlbakfile,'supporttoc.xml');

fidorig=fopen(xmlbakfile,'r');
fidedit=fopen(fullfile(xmlbakdir,'edit.xml'),'w');
%udela kopii casti pred upravou
for i=[1:(pos-1)]
    str = fgetl(fidorig);
    fprintf(fidedit,[str,'\n']);
end;
%vklada upravu
fprintf(fidedit,' <subtoc location="toolbox/physio/toc.xml" product="Physiology Blockset"></subtoc>\n\n');
%udela kopii casti po uprave
while ~(feof(fidorig))
    str = fgetl(fidorig);
    fprintf(fidedit,[str,'\n']);
end;
fclose(fidorig);
fclose(fidedit);

function [succes,xmldir,xmlfile]=zalohujxml(pthMwDocTocXml);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%  zalohuje MwDocToc.Xml pro verzi Matlab R13/R13SP1 %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
i=0;
succes=0;
workdir =fullfile(matlabroot,'work');
while (exist(fullfile(workdir,['pthXmlTmp',num2str(i)]))==7)
    i=i+1;
    %disp(['Pocet:',num2str(i)]);
    if i==100; break;end;
end;
mkdir(workdir,['pthXmlTmp',num2str(i)]);
xmldir=fullfile(workdir,['pthXmlTmp',num2str(i)]);
xmlfile=fullfile(xmldir,'mwdoctoc.xml');
[succes,mess,messid]=copyfile(pthMwDocTocXml,xmlfile);

function pos=najdi(prohledavanySoubor, hledanyRetezec)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% vraci cislo radky, ktera obsahuje hledany retezec, %%%%%%%%%%%%%
%%%%%%%%%%        v pripade neuspechu vraci -1                %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

str=' ';  % Inicializace
OK=0;    
pos=0;
fid = fopen(prohledavanySoubor); %zacatek prohledavani
while ~((OK)||(feof(fid)))
    pos=pos+1;%%%%%%%%%najde misto, pred ktere musim umistit svoji radku...
    str = fgetl(fid);
    OK = length(strfind(str,hledanyRetezec));
end;
if (feof(fid))&&(~OK) %%retezec nenalezen
    pos=-1;
end;
fclose(fid);      %konec prohledavani