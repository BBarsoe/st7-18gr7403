function f=physioUninst
global  pthDstLib pthDstHlp w maxwait
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%      PhysioLibrary UNInstalator for ver 1.2.1      %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%   Run without any parameters and follow the instructions      %%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% ujisteni, zda chci vubec neco odinstalovat
buttonName=questdlg('Do You want realy to uninstall the PHYSIOLOGY BLOCKSET? ','Uninstall the Physiology Blockset','YES, UNINSTALL','NO, ABORT','NO, ABORT');
switch buttonName
    case 'YES, UNINSTALL',
        disp('Uninstallation of "Physiology BlockSet" has been started.');
    case 'NO, ABORT',
        disp('Uninstallation has been interrupted. No changes to MATLAB environment have been done.');
        return;
end;

%%% zjisti, v ktere verzi matlabu vlastne je: R13/R13SP1   vs.  R14
structVer = ver('simulink');
strMyVer = structVer.Release;  % zname hodnoty: {'(R13)' , '(R13SP1)' , '(R14)' , '(R14SP1)' , '(R14SP2)'} , '(R14SP3)'

%%% definice waitbaru
hw = waitbar(0,'Please, be patient...');%WAITBAR%WAITBAR%WAITBAR
maxwait=10;w=0;

%%% skladam cesty (platformy maji ruzne oddelovace) 
w=mod(w+1,maxwait);waitbar(w/maxwait,hw,'I make up directory names'); %%%%%%%%%%%%%%%%
pthDstLib = fullfile(matlabroot,'toolbox','physio'); % cilove cesty
pthDstHlp = fullfile(matlabroot,'help','toolbox','physio');
pthXmlTmp = fullfile(matlabroot,'toolbox','physio','tmp'); % Tmp adresar pro upravy

w=mod(w+1,maxwait);waitbar(w/maxwait,hw);%WAITBAR%WAITBAR%WAITBAR%%WAITBAR
switch strMyVer % zdroje dat pro ruzne verze MATLABu
    case {'(R13)','(R13SP1)'}
        pthMwDocTocXml = fullfile(matlabroot,'help','mwdoctoc.xml'); % XML pro centralni registraci helpu
    case {'(R14)','(R14SP1)' , '(R14SP2)' , '(R14SP3)','(R2006a+)','(R2006b)','(R2007a)'}
    otherwise
        close(hw);
        h=msgbox('The Uninstalator can''t recognize the version of MATLAB. The uninstalation is abborted!!!'...
            ,'Uninstalation of PhysiologyBlockset Abborted','error');
        uiwait(h);
        return;
end %end switch

%%% mazani souboru
w=mod(w+1,maxwait);waitbar(w/maxwait,hw,'Preparing to remove files and paths...');%WAITBAR%WAITBAR%WAITBAR%%WAITBAR
if or(exist(pthDstLib)==7,exist(pthDstHlp)==7)
    buttonName=questdlg('Are you realy sure to uninstall the Physiology Blockset and remove all its files?', 'Uninstall the Physiology Blockset','Yes, unistall','No, abort','No, abort');
    succes1=1;
    succes2=1;
    error1=0;
    switch buttonName,  %POZOR! polozky musi souhlasit s vystupy predchazejiciho dialogu!!!
        case 'Yes, unistall',
            w=w+1;waitbar(w/maxwait,hw,'Removing MATLAB paths...');%WAITBAR%WAITBAR%WAITBAR%%WAITBAR
            warning off MATLAB:rmpath:DirNotFound;
            rmpath(pthDstLib);
            switch strMyVer % Zachova "search path" i pro pristi spusteni MATLABu. (Zavisi na verzi MATLABu)
                case {'(R13)','(R13SP1)'}
                    error1=path2rc;
                case {'(R14)','(R14SP1)','(R14SP2)','(R14SP3)','(R2006a+)','(R2006b)','(R2007a)'}
                    error1=savepath;
            end;
            w=w+1;waitbar(w/maxwait,hw,'Removing files and directories...');%WAITBAR%WAITBAR%WAITBAR%%WAITBAR
            if (exist(pthDstLib)==7)
                [succes1,mess1]=rmdir(pthDstLib,'s');
            end;
            if exist(pthDstHlp)==7
                [succes2,mess2]=rmdir(pthDstHlp,'s');
            end;
        case 'No, abort',
            close(hw);
            h=msgbox('Aborting uninstallation on user''s request. The Physiology Blockset is still installed.'...
                ,'Uninstalator of PhysiologyBlockset','warn');
            uiwait(h);
            return;
        otherwise
            disp('Nauc se programovat, osle.');
            close(hw);
            return;
    end
    if ~(error1==0)  %%%%% problem s MATLAB SEARCH PATH
        buttonName=questdlg('Failed to store updated "MATLAB search path"! ', 'PHYSIO Installation','Ignore','Abort','Ignore');
        switch buttonName
            case 'Ignore';
                h=msgbox('Resuming installation. Please check if "..\Toolbox\Physio\" path is not registered MATLAB Search Path after finishing the uninstallation process.','Uninstalator of PhysiologyBlockset','warn');
                uiwait(h);
            case 'Abort';
                h=msgbox('Aborting installation on user''s request. Please check if "..\Toolbox\Physio\" path is not registered MATLAB Search Path after finishing the uninstallation process','Uninstalator of PhysiologyBlockset','error');
                uiwait(h);
                close(hw);
                return;
        end;
    end;
    if (succes1==0)|(succes2==0) %%%%% problem s mazanim adresaru
        h=errordlg(['Uninstallation failed!!!  To fix this problem, please delete directories: ',pthDstLib,' and ',pthDstHlp,' and remove from "MATLAB search path" : ',pthDstLib],'Aborting uninstallation! Problem with directories occured.');
        uiwait(h);
        close(hw);
        return;
    end;
end;

%%% Registrace souboru pro help a registrace knihovny.
%%% Tato sekce je silne odlisna pro ruzne verze Matlabu !!!!
switch strMyVer
    case {'(R13)','(R13SP1)'} % v teto verzi Matlabu je nutna uprava souboru MwDocToc.Xml
        if exist(pthMwDocTocXml)==2;
            w=mod(w+1,maxwait);waitbar(w/maxwait,hw,'Checking "MWDocToc.XML"');%WAITBAR%WAITBAR%WAITBAR%%WAITBAR
            [succes,xmlbakdir,xmlbakfile]=zalohujxml(pthMwDocTocXml);
            if succes %%%%%%%% uprava MWDOCTOC.XML
                if  ~(najdi(xmlbakfile,'Physiology Blockset')==-1)
                    w=mod(w+1,maxwait);waitbar(w/maxwait,hw,'Updating "MWDocToc.XML"');%WAITBAR%WAITBAR%WAITBAR%%WAITBAR
                    vycistixml(xmlbakdir,xmlbakfile);%UPRAVUJE *.XML
                    w=mod(w+1,maxwait);waitbar(w/maxwait,hw,'Saving updated "MWDocToc.XML"');%WAITBAR%WAITBAR%WAITBAR%%WAITBAR
                    [succes,mess,messid]=copyfile(fullfile(xmlbakdir,'edit.xml'),pthMwDocTocXml); %starou verzi xml nahrad novou
                    if ~succes
                        h=msgbox(['Uninstallation failed!!!  To fix this problem, please restore ',pthMwDocTocXml,' from backup ',xmlbakfile,' .'],'Uninstalator of PhysiologyBlockset','error');
                        uiwait(h);
                        close(hw);
                        return;
                    end;
                else
                    h=msgbox('Help system table of contents "MWDocToc.XML" contain no "Physiology Blockset" item. Leaving unchanged','Uninstall the Physiology Blockset','warn');
                    uiwait(h);
                end;
            else
                h=msgbox(['Uninstallation failed!!! Failed to back up "MWDocToc.XML". Check the access rights for ',fullfile(matlabroot,'work'),' .'],'Uninstalator of PhysiologyBlockset','error');
                uiwait(h);
                close(hw);
                return
            end;
        else
            h=msgbox(['Uninstallation failed!!! "MWDocToc.XML" not found on the path: ',fullfile(matlabroot,'help'),' .'],'Uninstalator of PhysiologyBlockset','error');
            uiwait(h);
            close(hw);
            return;
        end;
    case {'(R14)','(R14SP1)','(R14SP2)','(R14SP3)','(R2006a+)','(R2006b)','(R2007a)'}
        %v teto verzi Matlabu se zadne soubory explicitne neupravuji
    otherwise
        close(hw);
        h=msgbox('The Instalator can''t recognize the version of MATLAB. The files may be unregistered!!! Edit MwDocToc.xml manualy if you have the R13 version.'...
            ,'Uninstalation of PhysiologyBlockset Abborted','error');
        uiwait(h);
        return;
end %end switch

%%%uzaviraci formule
close(hw);
buttonName=questdlg('Congratulations! "PHYSIOLOGY BLOCKSET" has been uninstalled successfully. It might be neccessary to restart MATLAB for the changes to take effect. Do you want to shut MATLAB down now or continue your session and restart MATLAB later?','Uninstalator of PhysiologyBlockset','Shut down MATLAB','Later','Shut down MATLAB');
switch buttonName
    case 'Shut down MATLAB'
        disp('Terminating sucessfully the uninstalation of Physiology BlockSet & Exiting MATLAB');
        quit;
    case 'Later'
        disp('Terminating sucessfully the uninstalation of Physiology BlockSet');
        disp('Changes may take efect after restarting MATLAB.');
%        return;
end;
%return;
pause(1);

function f=vycistixml(xmlbakdir,xmlbakfile);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%  odebere zname upravy z MwDocToc.Xml ve verzi Matlab R13/R13SP1 %%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
str=' ';
pos=0;
pos=najdi(xmlbakfile,'Physiology Blockset');

fidorig=fopen(xmlbakfile,'r');
fidedit=fopen(fullfile(xmlbakdir,'edit.xml'),'w');
%udela kopii casti pred upravou
for i=[1:(pos-1)]
    str = fgetl(fidorig);
    fprintf(fidedit,[str,'\n']);
end;
%ubere radek se zminkou o PhysiologyBlocksetu
    str = fgetl(fidorig);    
%udela kopii casti po uprave
while ~(feof(fidorig))
    str = fgetl(fidorig);
    fprintf(fidedit,[str,'\n']);
end;
fclose(fidorig);
fclose(fidedit);

function [succes,xmldir,xmlfile]=zalohujxml(pthMwDocTocXml);
global w maxwait
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%  zalohuje MwDocToc.Xml pro verzi Matlab R13/R13SP1 %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
i=0;
succes=0;
workdir =fullfile(matlabroot,'work');
while (exist(fullfile(workdir,['pthXmlTmp',num2str(i)]))==7)
    i=i+1;
    %disp(['Pocet:',num2str(i)]);
    if i==100; break;end;
end;
mkdir(workdir,['pthXmlTmp',num2str(i)]);
xmldir=fullfile(workdir,['pthXmlTmp',num2str(i)]);
xmlfile=fullfile(xmldir,'mwdoctoc.xml');
[succes,mess,messid]=copyfile(pthMwDocTocXml,xmlfile);

function pos=najdi(prohledavanySoubor, hledanyRetezec)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% vraci cislo radky, ktera obsahuje hledany retezec, %%%%%%%%%%%%%
%%%%%%%%%%        v pripade neuspechu vraci -1                %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

str=' ';  % Inicializace
OK=0;    
pos=0;
fid = fopen(prohledavanySoubor); %zacatek prohledavani
while ~((OK)|(feof(fid)))
    pos=pos+1;%%%%%%%%%najde misto, pred ktere musim umistit svoji radku...
    str = fgetl(fid);
    OK = length(strfind(str,hledanyRetezec));
end;
if (feof(fid))&(~OK) %%retezec nenalezen
    pos=-1;
end;
fclose(fid);      %konec prohledavani