Download the JModelica-1.13b1 from http://www.jmodelica.org/binary

(Ensure, that you have 32-bit Python27 installation. -https://www.python.org/download/releases/2.7.6/)

Please install the JModelica to the default directory
c:\JModelica.org-1.13b1\ (or modify path in runExamples.bat)

Verify the installation looking at c:\JModelica.org-1.13b1\JModelicaUsersGuide.pdf


