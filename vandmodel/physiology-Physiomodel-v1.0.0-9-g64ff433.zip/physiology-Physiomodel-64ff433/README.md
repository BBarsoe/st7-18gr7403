Physiomodel
===========

[www.physiomodel.org](http://www.physiomodel.org)

Physiomodel - quantitative model of human physiology in [Modelica](http://www.modelica.org) based on [HumMod 1.6.1](http://hummod.org) and [Physiolibrary 2.3.1](http://www.physiolibrary.org).




`Copyright (C) 2008-2015 Marek Mateják. Charles University in Prague. All rights reserved.`

[`Physiomodel License 1.0`](http://www.physiomodel.org/license.html)` means (`[`GPL 3.0`](http://www.gnu.org/licenses/gpl-3.0.en.html)`) for everybody or (`[`BSD 3-clause license`](http://opensource.org/licenses/BSD-3-Clause)`) between registered parties and possibility of distribution as a part of registered simulation environments.`
